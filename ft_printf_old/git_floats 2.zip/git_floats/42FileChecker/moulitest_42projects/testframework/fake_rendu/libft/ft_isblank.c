#include <libft.h>
int		ft_isblank(int c)
{
	(void)c;
	return (0);
}

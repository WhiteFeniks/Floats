#include <libft.h>
char	*ft_strcat(char *s1, const char *s2)
{
	(void)s1;
	return ((char *)s2);
}

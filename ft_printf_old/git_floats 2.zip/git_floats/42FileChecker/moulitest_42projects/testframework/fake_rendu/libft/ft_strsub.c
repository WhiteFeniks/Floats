#include <libft.h>
char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	(void)start;
	(void)len;
	return ((char *)s);
}

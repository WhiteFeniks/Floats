#include <libft.h>
size_t	ft_strlen(const char *s)
{
	(void)s;
	return (0);
}

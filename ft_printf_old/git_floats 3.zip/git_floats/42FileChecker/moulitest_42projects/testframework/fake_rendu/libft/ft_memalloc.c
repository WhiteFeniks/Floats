#include <libft.h>
void	*ft_memalloc(size_t size)
{
	(void)size;
	return (NULL);
}

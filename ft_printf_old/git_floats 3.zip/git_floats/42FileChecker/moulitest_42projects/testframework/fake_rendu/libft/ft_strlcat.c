#include <libft.h>
size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	(void)src;
	(void)dst;
	return (size);
}

#include <libft.h>
int		ft_isascii(int c)
{
	(void)c;
	return (0);
}

#include <libft.h>
void	ft_putnendl(char *s, size_t n)
{
	(void)s;
	(void)n;
}

#include <libft.h>
t_list		*ft_lstnew(void const *content, size_t content_size)
{
	(void)content;
	(void)content_size;
	return (NULL);
}

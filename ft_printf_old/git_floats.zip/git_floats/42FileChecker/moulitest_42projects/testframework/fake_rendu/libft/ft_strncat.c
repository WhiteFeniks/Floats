#include <libft.h>


char	*ft_strncat(char *s1, const char *s2, size_t n)
{
	(void)s2;
	(void)n;
	return (s1);
}

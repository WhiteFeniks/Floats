#include <libft.h>
char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	(void)f;
	return ((char *)s);
}

#include <libft.h>
int		ft_isdigit(int c)
{
	(void)c;
	return (0);
}
